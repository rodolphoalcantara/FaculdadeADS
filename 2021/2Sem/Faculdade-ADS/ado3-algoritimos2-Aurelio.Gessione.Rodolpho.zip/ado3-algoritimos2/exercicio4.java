package exercicios;

public class exercicio4 {

	/*
	 * 
	 * Alunos: Aurélio Bispo dos Santos, Gessione Freitas de Souza, Rodolpho Ramos de Alcântara
	 * 
	 * 
	 * Dada uma string, criar uma função recursiva (sem laços) que compute o número de caracteres’x’na string.
	 * Exemplos:
	 * contarX("xxhixx")→4
	 * contarX("xhixhix")→3
	 * contarX("hi")→0
	 * Dica: utilize os métodos length() e substring() da classe String
	*/
		
	public static void main(String[] args) {
		
		System.out.println(contarX("xxhixx"));
		System.out.println(contarX("xhixhix"));
		System.out.println(contarX("hi"));
	}
	
	public static int contarX(String str) {
		
		if(str.isEmpty()) {
			return 0;
		}
		if(str.charAt(0) == 'x') {
			return 1 + contarX(str.substring(1));
		}
		return 0 + contarX(str.substring(1));
	}
}
