create database if not exists lojainformatica;
use lojainformatica;

create table if not exists computador(
	id int not null auto_increment,
    marca varchar(40) not null,
    hd varchar(120) not null,
    processador varchar(120) not null,
    
    primary key (id)
);