/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rodolphoalcantara.lojainformatica.model;

/**
 *
 * @author rodolpho
 */
public class Computador {
    
    private int id;
    public static String marca = "RodolphoAlcantara";
    private String HD;
    private String processador;

    public Computador(){
        this.marca = "RodolphoAlcantara";
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
            
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getHD() {
        return HD;
    }

    public void setHD(String HD) {
        this.HD = HD;
    }

    public String getProcessador() {
        return processador;
    }

    public void setProcessador(String processador) {
        this.processador = processador;
    }
           
}
