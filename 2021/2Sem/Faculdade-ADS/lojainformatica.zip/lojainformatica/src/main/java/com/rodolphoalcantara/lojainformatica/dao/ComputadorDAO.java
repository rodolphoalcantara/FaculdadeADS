/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rodolphoalcantara.lojainformatica.dao;

import com.rodolphoalcantara.lojainformatica.model.Computador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rodolpho
 */
public class ComputadorDAO {

    private Connection connection;

    public ComputadorDAO(Connection connection) {
        this.connection = connection;
    }

    public void save(Computador computador) throws SQLException {
        try {
            String query = "insert into computador(marca, hd, processador) values (?,?,?)";

            try ( PreparedStatement pstm = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                pstm.setString(1, computador.getMarca());
                pstm.setString(2, computador.getHD());
                pstm.setString(3, computador.getProcessador());
                
                int linhasAfetadas = pstm.executeUpdate();
                
                if(linhasAfetadas > 0){
                    try(ResultSet rst = pstm.getGeneratedKeys()){
                        if(rst.next())
                            computador.setId(rst.getInt(1));
                    }
                }
            }
        }catch (SQLException e) {
            throw new SQLException("Não foi possível salvar");
        }finally{
            connection.close();
        }

    }

    public List<Computador> list(){
        try{
            List<Computador> computadores = new ArrayList<Computador>();
            String query = "select * from computador";
            
            try(PreparedStatement pstm = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS )){
                pstm.execute();
                
                resultSetToList(computadores, pstm);
            }
            
            return computadores;
            
        }catch(Exception e){
           e.printStackTrace();
        }
        
        return null;
    }
  
    public List<Computador> filter(String filter){
        try{
            List<Computador> computadores = new ArrayList<Computador>();
            String query = "select * from computador where marca like ?";
            
            try(PreparedStatement pstm = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)){
                
                pstm.setString(1, filter);
                pstm.execute();
                
                resultSetToList(computadores, pstm);
            }
            return computadores;
            
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
        
    public void resultSetToList(List<Computador> computadores, PreparedStatement pstm) throws SQLException{
        
        try(ResultSet rst = pstm.getResultSet()){
            while(rst.next()){
                Computador computador = new Computador();
                computador.setId(rst.getInt(1));
                computador.setMarca(rst.getString(2));
                computador.setHD(rst.getString(3));
                computador.setProcessador(rst.getString(4));
                
                computadores.add(computador);
                
            }
        }
        
    }

    public void delete(int id) {
        
        try{
            String query = "delete from computador where id = ?";
            try(PreparedStatement pstm = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)){
                
                pstm.setInt(1, id);
                pstm.execute();
                
            }
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        
    }

    public void update(Computador objComputador) {
        
        try{
            String query = "update computador c set c.marca = ?, c.hd = ?, c.processador = ? where id = ?";
            
            try(PreparedStatement pstm = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)){
                
                pstm.setString(1, objComputador.getMarca());
                pstm.setString(2, objComputador.getHD());
                pstm.setString(3, objComputador.getProcessador());
                pstm.setInt(4, objComputador.getId());
                
                pstm.execute();
            }
            
            
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        
        
    }
    
}
