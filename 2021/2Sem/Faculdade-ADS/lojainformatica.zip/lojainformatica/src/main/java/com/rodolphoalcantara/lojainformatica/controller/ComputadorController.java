/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rodolphoalcantara.lojainformatica.controller;

import com.rodolphoalcantara.lojainformatica.dao.ComputadorDAO;
import com.rodolphoalcantara.lojainformatica.model.Computador;
import com.rodolphoalcantara.lojainformatica.utils.GerenciadorConexao;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JTable;

/**
 *
 * @author rodolpho
 */
public class ComputadorController {

    ComputadorDAO computadorDAO;

    public ComputadorController() {
        
        try{
            Connection connection = GerenciadorConexao.getConnection();
            this.computadorDAO = new ComputadorDAO(connection);
        }catch(SQLException e){
            e.printStackTrace();
        }catch(ClassNotFoundException e){
            e.printStackTrace();
        }
    }

    public Computador salvar(Computador computador) throws SQLException {
        computadorDAO.save(computador);
        return computador;
    }
    
    public List<Computador> listar(){
        return this.computadorDAO.list();
    }
    
    public List<Computador> filtrar(String filtro){
        
        List<Computador> computadores = this.computadorDAO.filter(filtro);
        
        if(computadores.isEmpty()){
            throw new IllegalArgumentException("Não foi encontrado nenhum computador para esta marca!");
        }
        
        return computadores;
    }
    
    public Computador transformarLinhaTabelaEmComputador(JTable tabela, int linhaSelecionada){
        
        if((linhaSelecionada >= 0) && (linhaSelecionada <= tabela.getRowCount()) && (tabela != null)){
            Computador computador = new Computador();

            computador.setId((int)tabela.getValueAt(linhaSelecionada, 0));
            computador.setMarca((String)tabela.getValueAt(linhaSelecionada, 1));
            computador.setHD((String)tabela.getValueAt(linhaSelecionada, 2));
            computador.setProcessador((String)tabela.getValueAt(linhaSelecionada, 3));

            return computador;
        }
        throw new RuntimeException("Não foi possível selecionar o computador.");
    }

    public void deletar(int id) {
        this.computadorDAO.delete(id);
    }

    public void alterar(Computador objComputador) {
        this.computadorDAO.update(objComputador);
    }

}
